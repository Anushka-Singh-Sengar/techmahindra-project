package com.example.techmahindra.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {
    // Business logic if needed
}
