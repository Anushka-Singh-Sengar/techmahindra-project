package com.example.techmahindra.controller;

import com.example.techmahindra.model.ContactMessage;
import com.example.techmahindra.repository.ContactMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = {"http://localhost:5500", "http://127.0.0.1:5500", "http://localhost:3000"})
@RestController
@RequestMapping("/api/contact")
public class ContactController {

    @Autowired
    private ContactMessageRepository contactMessageRepository;

    @PostMapping
    public ContactMessage submitContactForm(@RequestBody ContactMessage contactMessage) {
        return contactMessageRepository.save(contactMessage);
    }
}