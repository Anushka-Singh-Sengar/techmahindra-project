package com.example.techmahindra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechmahindraApplication {
    public static void main(String[] args) {
        SpringApplication.run(TechmahindraApplication.class, args);
    }
}
